class InvalidReplayException(Exception):
    pass

class ReadStringException(Exception):
    pass

class FrameParsingException(Exception):
    pass

class PlayerEliminationException(Exception):
    pass
